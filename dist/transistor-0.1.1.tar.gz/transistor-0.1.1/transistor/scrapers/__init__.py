# -*- coding: utf-8 -*-
"""
transistor.scrapers
~~~~~~~~~~~~
This module contains classes and lua scripts to setup a scraper.

:copyright: Copyright (C) 2018 by BOM Quote Limited
:license: The MIT License, see LICENSE for more details.
~~~~~~~~~~~~
"""
from .splash_scraper_abc import SplashScraper