# -*- coding: utf-8 -*-

from .shell import SplashScraperShell
from .extractor import ScrapedDataExtractor