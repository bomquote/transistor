# -*- coding: utf-8 -*-
"""
transistor.utility
~~~~~~~~~~~~
This module contains classes, methods, and functions as found useful to include in
the Transistor source code.

:copyright: Copyright (C) 2018 by BOM Quote Limited
:license: The MIT License, see LICENSE for more details.
~~~~~~~~~~~~
"""