# -*- coding: utf-8 -*-
"""
transistor.tests.books_toscrape
~~~~~~~~~~~~
This module implements testing to check Transistor source code.

:copyright: Copyright (C) 2018 by BOM Quote Limited
:license: The MIT License, see LICENSE for more details.
~~~~~~~~~~~~
"""