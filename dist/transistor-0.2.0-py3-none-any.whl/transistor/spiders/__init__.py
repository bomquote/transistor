# -*- coding: utf-8 -*-
"""
transistor.spiders
~~~~~~~~~~~~
This module is a placeholder work-in-progress but will eventually implement a more
optimized design for a crawling spider class which can be scaled with gevent
based asynchronous I/O, similar to SplashScraper.

:copyright: Copyright (C) 2018 by BOM Quote Limited
:license: The MIT License, see LICENSE for more details.
~~~~~~~~~~~~
"""